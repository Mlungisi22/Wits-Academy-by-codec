package com.example.login;

public class quizName {
    public String quizname;
    public quizName(){
    }
    public quizName(String quizname){
        setQuizname(quizname);
    }

    public String getQuizname() {
        return quizname;
    }

    public void setQuizname(String quizname) {
        this.quizname = quizname;
    }
}
